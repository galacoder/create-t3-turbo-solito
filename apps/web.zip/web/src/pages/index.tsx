import { HomeScreen } from "@aeonbook/core/features/home/screen";

export default HomeScreen;
